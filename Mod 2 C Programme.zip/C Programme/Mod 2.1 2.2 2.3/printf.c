#include<stdio.h>

int main()
{
	
	printf("Name : Dixit patel");
	printf("\n\nDate of Birth : 24th nov");
	printf("\n\nAge : 26");
	printf("\n\nAddress : ahmedabad");
	
	return 0;
}
