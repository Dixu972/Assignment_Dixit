# include <stdio.h>
 

int reverse(char *str)
{
  if (*str)
  {
    reverse(str + 1);
    printf("%c", *str);
    return 0; 
  }
}

int main()
{
  char a[] = "dixit";
  reverse(a);
  return 0;
}
