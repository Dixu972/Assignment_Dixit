//Find Vowel and consonant using switch case.

#include<stdio.h>

int main()
{
	
	char ch;
	
	printf("Enter any character to find vowel or consonant : ");
	scanf("%c",&ch);
	
	switch(ch)
	{
		case 'a':
			printf("Vowel...!");
		break;
		
		case 'e':
			printf("Vowel...!");
		break;
		
		case 'i':
			printf("Vowel...!");
		break;
		
		case 'o':
			printf("Vowel...!");
		break;
		
		case 'u':
			printf("Vowel...!");
		break;
		
		case 'A':
			printf("Vowel...!");
		break;
		
		case 'E':
			printf("Vowel...!");
		break;
		
		case 'I':
			printf("Vowel...!");
		break;
		
		case 'O':
			printf("Vowel...!");
		break;
		
		case 'U':
			printf("Vowel...!");
		break;
		
		
		default:
			printf("Consonant...!");
		
	}
	
	return 0;
}