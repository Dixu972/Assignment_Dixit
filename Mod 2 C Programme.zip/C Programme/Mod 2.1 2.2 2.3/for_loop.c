//For Loop Program

#include<stdio.h>

int main()
{
	int a;
	for(a=972;a>=897;a--)
	{
		printf("%i \n",a);
	}
	
	return 0;
}