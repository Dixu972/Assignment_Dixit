#include<stdio.h>
int main()
{
	printf("\t\t-----Your Details-----\n");
	printf("\t\tYour Name :	DIXIT\n");
	printf("\t\tYour Birth date :24/11/1993\n");
	printf("\t\tYour Age :	30\n");
	printf("\t\tAddress : 	A1, SARTHI PARISHAR,Ahmedabad,Gujarat\n");
	return 0;
}
