#include<stdio.h>
void main()
{
	int l,w,area;
	printf("Enter length of rectangle\n");
	scanf("%d",&l);
	printf("Enter widht of rectangle\n");
	scanf("%d",&w);
	area=l*w;
	printf("total rectangle area is:%d",area);
}
