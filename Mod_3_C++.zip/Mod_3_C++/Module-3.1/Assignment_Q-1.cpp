/*1). WAP to print �Hello World� using C++ */
#include<iostream>
using namespace std;
int main()
{
	cout<<"Hello World";
	return 0;
}
